<div class="text-center card-body px-0">
    <div class="inbox-widget">
        <table id="datatable{{ $department_id }}" class="table table-bordered w-100">
            <thead>
                <tr class='m-0 p-0'>
                    <th>Team Member</th>
                     <th>Job title</th>
                    <th>Manager</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        
    </div>
</div>

<script>
 user_id ="{{ $user_id }}";
</script>