@extends('user.layouts.app')

@section('content')

<div class="container p-0">
<div class="card">
    <div class="card-body"> 
    <h4>Talent Search</h4>
    </div>
</div>
</div>

@endsection

