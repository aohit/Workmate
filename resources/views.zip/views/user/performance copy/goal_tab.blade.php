<div class="row">
    <div class="col-12">
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="userName">User name</label>
            <div class="col-md-9">
                <input type="text" class="form-control" id="userName" name="userName" value="Coderthemes">
            </div>
        </div>
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="password"> Password</label>
            <div class="col-md-9">
                <input type="password" id="password" name="password" class="form-control" value="123456789">
            </div>
        </div>
        
        <div class="row mb-3">
            <label class="col-md-3 col-form-label" for="confirm">Re Password</label>
            <div class="col-md-9">
                <input type="password" id="confirm" name="confirm" class="form-control" value="123456789">
            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->