<div class="text-center card-body px-0">
    <div class="inbox-widget">
        <table id="datatable{{ $department_id }}" class="table table-borderless mb-0 dt-responsive table-responsive nowrap">
            <thead>
                <tr>
                    <th>Team Member</th>
                    <th>Department</th>
                    <th>Manager</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        
    </div>
</div>

<script>
    user_id ="{{ $user_id }}";
</script>