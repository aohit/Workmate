@extends('user.layouts.app')

@section('content')


<div class="container-fluid">
    
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body"> 
                  <h3>My Team</h3>
                </div>
            </div>

        </div>
    </div> <!-- end row -->

</div>
@endsection


